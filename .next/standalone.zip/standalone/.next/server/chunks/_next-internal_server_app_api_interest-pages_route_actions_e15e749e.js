module.exports=[47032,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_interest-pages_route_actions_e15e749e.js.map