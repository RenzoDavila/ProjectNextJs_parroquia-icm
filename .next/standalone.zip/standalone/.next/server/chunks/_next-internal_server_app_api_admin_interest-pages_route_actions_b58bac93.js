module.exports=[14842,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_interest-pages_route_actions_b58bac93.js.map