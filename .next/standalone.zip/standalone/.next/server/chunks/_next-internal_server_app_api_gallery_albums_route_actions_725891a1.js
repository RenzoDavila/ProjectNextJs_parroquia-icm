module.exports=[88815,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gallery_albums_route_actions_725891a1.js.map