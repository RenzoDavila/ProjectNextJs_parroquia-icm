module.exports=[2094,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_mass-pricing_%5Bid%5D_route_actions_b8e7ef43.js.map