module.exports=[51531,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_parish-groups_route_actions_7e111f9e.js.map