module.exports=[77911,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_banners_route_actions_a33b692a.js.map