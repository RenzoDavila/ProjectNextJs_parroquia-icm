module.exports=[51220,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_settings_route_actions_fd998405.js.map