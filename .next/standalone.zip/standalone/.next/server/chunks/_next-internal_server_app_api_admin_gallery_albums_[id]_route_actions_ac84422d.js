module.exports=[98710,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_gallery_albums_%5Bid%5D_route_actions_ac84422d.js.map