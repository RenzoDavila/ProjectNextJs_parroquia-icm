module.exports=[48887,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_parish-groups_route_actions_cbb4a667.js.map