module.exports=[92128,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_interest-pages_%5Bid%5D_route_actions_46386503.js.map