module.exports=[66886,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mass-schedules_route_actions_662ddee3.js.map