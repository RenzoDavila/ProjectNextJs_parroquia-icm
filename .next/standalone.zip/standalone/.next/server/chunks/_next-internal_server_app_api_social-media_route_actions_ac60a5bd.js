module.exports=[29592,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_social-media_route_actions_ac60a5bd.js.map