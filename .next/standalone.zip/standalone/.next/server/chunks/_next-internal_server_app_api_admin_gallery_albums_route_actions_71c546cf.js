module.exports=[50660,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_gallery_albums_route_actions_71c546cf.js.map