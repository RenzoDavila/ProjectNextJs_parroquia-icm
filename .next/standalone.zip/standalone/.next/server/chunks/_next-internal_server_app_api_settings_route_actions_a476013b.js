module.exports=[64538,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_settings_route_actions_a476013b.js.map