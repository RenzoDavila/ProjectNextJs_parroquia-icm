module.exports=[27320,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_home-services_route_actions_2b2a43df.js.map