module.exports=[34790,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_contacto_page_actions_43fd41a0.js.map