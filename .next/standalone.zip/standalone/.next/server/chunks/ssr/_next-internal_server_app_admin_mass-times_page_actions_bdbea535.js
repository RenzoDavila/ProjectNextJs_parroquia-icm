module.exports=[50536,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_mass-times_page_actions_bdbea535.js.map