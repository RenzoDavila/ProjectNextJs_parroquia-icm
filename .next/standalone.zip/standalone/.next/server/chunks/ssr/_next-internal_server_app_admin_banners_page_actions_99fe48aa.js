module.exports=[4809,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_banners_page_actions_99fe48aa.js.map