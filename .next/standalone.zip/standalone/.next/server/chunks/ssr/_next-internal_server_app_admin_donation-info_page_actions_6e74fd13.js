module.exports=[44312,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_donation-info_page_actions_6e74fd13.js.map