module.exports=[81755,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_pages_page_actions_541b7841.js.map