module.exports=[15032,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_messages_page_actions_1c7fcb08.js.map