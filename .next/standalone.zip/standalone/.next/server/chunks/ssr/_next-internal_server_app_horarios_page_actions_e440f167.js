module.exports=[50057,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_horarios_page_actions_e440f167.js.map