module.exports=[40715,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_servicios_page_actions_9c0e4a66.js.map