module.exports=[95608,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_social-media_page_actions_24308574.js.map