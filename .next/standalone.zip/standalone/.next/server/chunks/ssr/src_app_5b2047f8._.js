module.exports=[10585,a=>{a.v("/_next/static/media/favicon.918d3f76.ico")},68611,a=>{"use strict";let b={src:a.i(10585).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_5b2047f8._.js.map