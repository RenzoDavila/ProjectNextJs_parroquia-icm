module.exports=[64852,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_home-content_page_actions_853385d5.js.map