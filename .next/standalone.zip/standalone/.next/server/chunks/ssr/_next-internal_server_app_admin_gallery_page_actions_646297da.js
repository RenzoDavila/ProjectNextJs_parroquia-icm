module.exports=[79612,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_gallery_page_actions_646297da.js.map