module.exports=[68654,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_nosotros_page_actions_8f7d9f9e.js.map