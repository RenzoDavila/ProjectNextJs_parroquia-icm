module.exports=[74780,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_galeria_page_actions_84f8311b.js.map