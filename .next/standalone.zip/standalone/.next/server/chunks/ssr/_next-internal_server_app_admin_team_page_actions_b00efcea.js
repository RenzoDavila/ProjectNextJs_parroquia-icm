module.exports=[62439,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_team_page_actions_b00efcea.js.map