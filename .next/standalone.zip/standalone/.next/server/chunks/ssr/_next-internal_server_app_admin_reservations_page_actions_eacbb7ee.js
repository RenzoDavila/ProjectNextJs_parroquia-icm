module.exports=[85840,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_reservations_page_actions_eacbb7ee.js.map