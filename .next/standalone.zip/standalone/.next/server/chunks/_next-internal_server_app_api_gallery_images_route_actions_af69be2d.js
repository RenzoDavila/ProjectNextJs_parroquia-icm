module.exports=[11246,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gallery_images_route_actions_af69be2d.js.map