module.exports=[83964,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_mass-pricing_route_actions_e503daca.js.map