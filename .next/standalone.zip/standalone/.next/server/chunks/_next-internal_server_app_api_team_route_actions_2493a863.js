module.exports=[43955,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_team_route_actions_2493a863.js.map