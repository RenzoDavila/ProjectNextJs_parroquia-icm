module.exports=[877,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_stats_route_actions_05832952.js.map