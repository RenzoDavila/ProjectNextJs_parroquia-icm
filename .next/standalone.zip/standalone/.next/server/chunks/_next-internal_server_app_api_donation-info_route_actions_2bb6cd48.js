module.exports=[87420,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_donation-info_route_actions_2bb6cd48.js.map