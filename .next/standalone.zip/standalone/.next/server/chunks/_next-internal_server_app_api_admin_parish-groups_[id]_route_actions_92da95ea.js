module.exports=[94429,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_parish-groups_%5Bid%5D_route_actions_92da95ea.js.map