module.exports=[79358,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_reservations_route_actions_79fee522.js.map