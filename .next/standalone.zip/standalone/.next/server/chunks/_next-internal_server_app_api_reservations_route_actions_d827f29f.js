module.exports=[67005,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reservations_route_actions_d827f29f.js.map