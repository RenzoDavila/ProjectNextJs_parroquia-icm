module.exports=[40001,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_office-hours_route_actions_924bd232.js.map