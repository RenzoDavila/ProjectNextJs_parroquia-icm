module.exports=[66616,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_team_%5Bid%5D_route_actions_175fec50.js.map