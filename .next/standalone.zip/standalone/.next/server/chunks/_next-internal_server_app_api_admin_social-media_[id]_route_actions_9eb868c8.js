module.exports=[24067,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_social-media_%5Bid%5D_route_actions_9eb868c8.js.map