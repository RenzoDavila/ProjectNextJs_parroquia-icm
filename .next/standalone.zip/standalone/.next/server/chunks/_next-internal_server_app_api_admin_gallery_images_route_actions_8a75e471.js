module.exports=[83080,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_gallery_images_route_actions_8a75e471.js.map