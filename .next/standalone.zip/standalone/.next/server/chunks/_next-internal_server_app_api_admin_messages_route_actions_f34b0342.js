module.exports=[35461,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_messages_route_actions_f34b0342.js.map