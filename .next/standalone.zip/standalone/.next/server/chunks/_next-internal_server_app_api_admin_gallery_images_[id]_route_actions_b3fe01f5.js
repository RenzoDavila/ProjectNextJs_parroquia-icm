module.exports=[57154,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_gallery_images_%5Bid%5D_route_actions_b3fe01f5.js.map