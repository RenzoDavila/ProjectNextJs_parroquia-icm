module.exports=[64310,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_donation-info_%5Bid%5D_route_actions_71a58511.js.map