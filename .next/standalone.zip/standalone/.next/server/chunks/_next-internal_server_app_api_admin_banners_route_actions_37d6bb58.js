module.exports=[24739,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_banners_route_actions_37d6bb58.js.map