module.exports=[39693,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mass-types_route_actions_855fe750.js.map