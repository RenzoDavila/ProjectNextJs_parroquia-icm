module.exports=[9115,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_mass-times_%5Bid%5D_route_actions_7e8260d0.js.map