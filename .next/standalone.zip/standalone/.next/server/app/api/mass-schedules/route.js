var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/mass-schedules/route.js")
R.c("server/chunks/[root-of-the-server]__2133f2ff._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_mass-schedules_route_actions_662ddee3.js")
R.m(52789)
module.exports=R.m(52789).exports
