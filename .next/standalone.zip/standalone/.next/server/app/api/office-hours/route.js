var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/office-hours/route.js")
R.c("server/chunks/[root-of-the-server]__ac3ab379._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_office-hours_route_actions_924bd232.js")
R.m(8585)
module.exports=R.m(8585).exports
