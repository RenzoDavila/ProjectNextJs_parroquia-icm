var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reservations/route.js")
R.c("server/chunks/[root-of-the-server]__b7d70cff._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_reservations_route_actions_d827f29f.js")
R.m(69597)
module.exports=R.m(69597).exports
