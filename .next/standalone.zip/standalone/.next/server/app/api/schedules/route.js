var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/schedules/route.js")
R.c("server/chunks/[root-of-the-server]__4b6d96db._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_schedules_route_actions_f5db3d09.js")
R.m(29646)
module.exports=R.m(29646).exports
