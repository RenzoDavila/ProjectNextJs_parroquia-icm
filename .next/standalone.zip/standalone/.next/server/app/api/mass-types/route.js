var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/mass-types/route.js")
R.c("server/chunks/[root-of-the-server]__de5e9c85._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_mass-types_route_actions_855fe750.js")
R.m(91375)
module.exports=R.m(91375).exports
