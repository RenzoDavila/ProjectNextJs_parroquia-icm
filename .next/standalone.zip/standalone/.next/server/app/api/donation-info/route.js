var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/donation-info/route.js")
R.c("server/chunks/[root-of-the-server]__7755deca._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_donation-info_route_actions_2bb6cd48.js")
R.m(70405)
module.exports=R.m(70405).exports
