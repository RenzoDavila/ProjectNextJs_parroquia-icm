var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/social-media/route.js")
R.c("server/chunks/[root-of-the-server]__7e4a5323._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_social-media_route_actions_ac60a5bd.js")
R.m(62760)
module.exports=R.m(62760).exports
