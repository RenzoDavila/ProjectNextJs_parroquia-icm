var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/team/route.js")
R.c("server/chunks/[root-of-the-server]__0a866010._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_team_route_actions_2493a863.js")
R.m(26936)
module.exports=R.m(26936).exports
