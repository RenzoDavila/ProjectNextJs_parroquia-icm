var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/parish-groups/route.js")
R.c("server/chunks/[root-of-the-server]__952b2b0a._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_parish-groups_route_actions_7e111f9e.js")
R.m(29110)
module.exports=R.m(29110).exports
