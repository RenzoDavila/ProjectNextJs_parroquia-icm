var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/payment-methods/route.js")
R.c("server/chunks/[root-of-the-server]__a453d246._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_payment-methods_route_actions_fef9c9b4.js")
R.m(9430)
module.exports=R.m(9430).exports
