var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/home-services/route.js")
R.c("server/chunks/[root-of-the-server]__3c45936b._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_home-services_route_actions_eb4b7ac5.js")
R.m(9829)
module.exports=R.m(9829).exports
