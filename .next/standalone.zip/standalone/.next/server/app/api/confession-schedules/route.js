var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/confession-schedules/route.js")
R.c("server/chunks/[root-of-the-server]__8a050be2._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_confession-schedules_route_actions_9bf737b7.js")
R.m(65326)
module.exports=R.m(65326).exports
