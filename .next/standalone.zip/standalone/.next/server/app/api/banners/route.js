var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/banners/route.js")
R.c("server/chunks/[root-of-the-server]__f213fbd1._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_banners_route_actions_a33b692a.js")
R.m(91832)
module.exports=R.m(91832).exports
