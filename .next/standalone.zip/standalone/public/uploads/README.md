# Uploads - Imágenes subidas por el administrador

Todas las imágenes se guardan en la carpeta `public/` del proyecto.

## Estructura:
- `banners/` - Imágenes de los banners del home
- `services/` - Imágenes de servicios
- `gallery/` - Imágenes de la galería
- `team/` - Fotos del equipo pastoral
- `general/` - Otras imágenes

**Nota:** Los archivos subidos NO se suben a Git (ver .gitignore)
